package com.example.common;

public class Result {
    private String code;
    private String msg;
    private Object data;

    // 无参成功（不返回数据）
    public static Result success() {
        Result result = new Result();
        result.setCode("200");
        result.setMsg("成功");
        return result;
    }

    // 有参成功（返回数据）
    public static Result success(Object data) {
        Result result = new Result();
        result.setCode("200");
        result.setMsg("成功");
        result.setData(data);
        return result;
    }

    public static Result error(String code, String msg) {
        Result result = new Result();
        result.setCode(code);
        result.setMsg(msg);
        return result;
    }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getMsg() { return msg; }
    public void setMsg(String msg) { this.msg = msg; }
    public Object getData() { return data; }
    public void setData(Object data) { this.data = data; }
}