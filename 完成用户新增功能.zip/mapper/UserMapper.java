package com.example.mapper;

import com.example.entity.User;

public interface UserMapper {

    /**
     * 新增
     */
    int insert(User user);

}