package com.example.entity;

public class User extends Account {
    /** 性别 (User 独有的字段) */
    private String sex;

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }
}